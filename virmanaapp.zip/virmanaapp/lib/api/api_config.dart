


class apiConfig{
  static const String api_url  = "https://football.virmana.com/api/";
  static const String api_token  = "4F5A9C3D9A86FA54EACEDDD635185";
  static const String item_purchase_code  = "4F5A9C3D9A86FA54EACEDDD635185";
}
