class Event {
  final int? id;
  final String? type;
  final String? time;
  final String? title;
  final String? subtitle;
  final String? image;
  final String? name;


  Event({this.id, this.type, this.time, this.title, this.subtitle, this.image, this.name});

  factory Event.fromJson(Map<String, dynamic> parsedJson){
    return Event(
      id: parsedJson['id'] == null ? -1 : parsedJson['id'],
      type : parsedJson['type'] == null ? "" : parsedJson['type'],
      time : parsedJson ['time'] == null ? "" : parsedJson['time'],
      title : parsedJson ['title'] == null ? "" : parsedJson['title'],
      subtitle : parsedJson ['subtitle'] == null ? "" : parsedJson['subtitle'],
      image : parsedJson ['image'] == null ? "" : parsedJson['image'],
      name : parsedJson ['name'] == null ? "" : parsedJson['name']
    );
  }
}
