
class Trophy {
  final int? id;
  final String? title;
  final String? description;
  final String? content;
  final String? image;
  final String? icon;
  final int? position;
  final String? number;


  Trophy( {this.id, this.title,this.description,this.content, this.image,this.icon,this.position,this.number});

  factory Trophy.fromJson(Map<String, dynamic> parsedJson){
    return Trophy(
      id: parsedJson['id'] == null ? -1 : parsedJson['id'],
      title : parsedJson['title'] == null ? "" : parsedJson['title'],
      description : parsedJson['description'] == null ? "" : parsedJson['description'],
      content : parsedJson['content'] == null ? "" : parsedJson['content'],
      image : parsedJson ['image'] == null ? "" : parsedJson['image'],
      icon : parsedJson ['icon'] == null ? "" : parsedJson['icon'],
      position : parsedJson ['position'] == null ? 0 : parsedJson['position'],
      number : parsedJson ['number'] == null ? "" : parsedJson['number']
    );
  }
}
