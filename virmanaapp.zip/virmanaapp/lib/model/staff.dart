
class Staff {
  final int? id;
  final String? name;
  final String? status;
  final String? image;
  final String? bio;


  Staff({this.id, this.name,this.status, this.image,this.bio});

  factory Staff.fromJson(Map<String, dynamic> parsedJson){
    return Staff(
      id: parsedJson['id'] == null ? -1 : parsedJson['id'],
      name : parsedJson['name'] == null ? "" : parsedJson['name'],
      status : parsedJson['status'] == null ? "" : parsedJson['status'],
      image : parsedJson ['image'] == null ? "" : parsedJson['image'],
      bio : parsedJson ['bio'] == null ? "" : parsedJson['bio'],
    );
  }
}
