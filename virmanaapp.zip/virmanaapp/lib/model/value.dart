
import 'package:myteam/model/player.dart';

class Value {
  final int? id;
  final String? name;
  final String? value;

  Value( {this.id, this.name,this.value});

  factory Value.fromJson(Map<String, dynamic> parsedJson){

    return Value(
        id: parsedJson['id'] == null ? -1 : parsedJson['id'],
        name : parsedJson['name'] == null ? "" : parsedJson['name'],
        value : parsedJson['value'] == null ? "" : parsedJson['value']
    );
  }
}
