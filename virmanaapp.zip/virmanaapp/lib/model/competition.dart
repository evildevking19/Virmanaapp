import 'package:myteam/model/table.dart';

class Competition {
  final int? id;
  final String? name;
  final String? image;
  final String? season;
  final List<Table>? tables;
  bool selected = false;


  Competition( {this.id, this.name, this.image,this.tables, this.season,this.selected = false});

  factory Competition.fromJson(Map<String, dynamic> parsedJson){


    List<Table> tablesList = [] ;
    var data = parsedJson['tables'];
    if(data != null) {
      for (Map<String, dynamic> i in data) {
        tablesList.add(Table.fromJson(i));
      }
    }

    return Competition(
        id: parsedJson['id'] == null ? -1 : parsedJson['id'],
        name : parsedJson['name'] == null ? "" : parsedJson['name'],
        image : parsedJson['image'] == null ? "" : parsedJson['image'],
        tables : tablesList,
        season : parsedJson['season'] == null ? "" : parsedJson['season']
    );
  }
}
