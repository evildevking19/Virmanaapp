
class Club {
  final int? id;
  final String? name;
  final String? image;


  Club({this.id, this.name, this.image});

  factory Club.fromJson(Map<String, dynamic> parsedJson){
    return Club(
      id: parsedJson['id'] == null ? -1 : parsedJson['id'],
      name : parsedJson['name'] == null ? "" : parsedJson['name'],
      image : parsedJson ['image'] == null ? "" : parsedJson['image']
    );
  }
}
