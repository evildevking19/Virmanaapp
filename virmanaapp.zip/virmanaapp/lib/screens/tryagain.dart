// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';
class TryAgainButton extends StatelessWidget {
  Function action;

  TryAgainButton({ required this.action});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextButton.icon(
            style: TextButton.styleFrom(
              foregroundColor: Theme.of(context).colorScheme.secondary,
            ),
            onPressed: action(),
            icon: Icon(LineIcons.syncIcon,color: Colors.white,),
            label: Text(
              "Try Again",
              style: TextStyle(
                  color: Colors.white
              ),
            ),
          ),
        ],
      ),
    );
  }
}

