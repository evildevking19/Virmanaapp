import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:myteam/config/colors.dart';

class LoadingWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child:  SpinKitFoldingCube(
        size: 35,
        duration: Duration(seconds: 2),
        itemBuilder: (BuildContext context, int index) {
          return DecoratedBox(
            decoration: BoxDecoration(
              color: index.isEven ? Theme.of(context).colorScheme.secondary : Theme.of(context).colorScheme.secondary,
            ),
          );
        },
      ),
    );
  }
}
