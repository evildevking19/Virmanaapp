
import 'package:flutter/material.dart';

class Config{
  static  String appName = "";

  static  String subName   = "";
}